package com.bilgeadam.lesson021.okulapp;

public class Ogretmen {

}
